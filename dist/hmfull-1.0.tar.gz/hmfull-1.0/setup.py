from setuptools import setup, find_packages


setup(
    name='hmfull',
    version='1.0',
    license='ISC',
    author="Alice Addison",
    author_email='alice@alicesworld.tech',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='none',
    keywords= ["anime", "hentai", "nsfw", "sfw", "images", "gifs", "wallpaper", "discord", "ahegao", "ass", "neko", "kitsune", "yuri", "panties", "thighs", "foot", "overwatch", "dva", "erotic", "lewdkemo", "lewdneko", "lewdkitsune", "holo", "bj", "spank", "ero", "kawaii", "cute", "waifu", "hmtai", "zettaiRyouiki", "18+", "REST", "API", "Mikun"],
    install_requires=[
          'requests',
      ],

)